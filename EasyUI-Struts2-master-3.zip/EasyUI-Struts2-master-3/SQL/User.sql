database is yiwan

create TABLE user(
userid int PRIMARY KEY auto_increment,
username varchar(30),
password varchar(30)
);

insert into `user` (`userid`, `username`, `password`) values(null,'aaa','123');
insert into `user` (`userid`, `username`, `password`) values(null,'df2','123');
insert into `user` (`userid`, `username`, `password`) values(null,'45ty','123');
insert into `user` (`userid`, `username`, `password`) values(null,'sdfy','123');

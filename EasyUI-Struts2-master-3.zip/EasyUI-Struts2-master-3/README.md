EasyUI-Struts2
==============

An easy project using EasyUI,Struts2 and JSON

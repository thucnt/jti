package junit_test;

public class A {
	static{
		System.out.println("df");
	}
}

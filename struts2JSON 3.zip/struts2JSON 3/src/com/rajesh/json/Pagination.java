package com.rajesh.json;

import java.util.List;

public class Pagination {//This is our paging object
	/**
	 * The total number of records
	 */
	private long counts;
	/**
	 * The first few pages
	 */
	private Integer pageNo=1;
	/**
	 * The number of records per page, the default value is 10
	 */
	private Integer pageSize=10;
	/**
	 * The total number of pages
	 */
	private int pageCount;
	/**
	 * Success
	 */
	private boolean suc;
	/**
	 * The current page displayed record
	 */
	private List reusltList;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public List<Object> getReusltList() {
		return reusltList;
	}

	public void setReusltList(List reusltList) {
		this.reusltList = reusltList;
	}

	public long getCounts() {
		return counts;
	}

	public boolean isSuc() {
		return suc;
	}

	public void setSuc(boolean suc) {
		this.suc = suc;
	}

	public void setCounts(long counts) {
		if(counts % pageSize == 0) {
			pageCount = (int)counts / pageSize;
		}else {
			pageCount = (int)(counts + pageSize) / pageSize;
		}
		if(pageNo<1){
			pageNo = 1;
		}else if(pageNo > pageCount) {
			pageNo = pageCount;
		}
		this.counts = counts;
	}
	
}